package ch.heigvd.daa_labo3.model.entities

enum class State {
    IN_PROGRESS, DONE
}