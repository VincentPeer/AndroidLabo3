package ch.heigvd.daa_labo3.model.entities

public enum class Type {
    NONE, TODO, SHOPPING, WORK, FAMILY
}